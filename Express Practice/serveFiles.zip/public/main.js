document.getElementById('but').addEventListener('click',function(){
    console.log('hit...')
})