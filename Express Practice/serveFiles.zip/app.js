var express = require('express')
var bodyParser = require('body-parser')
const path = require('path')
const app = express()

// var logger = function(req,res,next){
//     console.log('Logging with: ',req);
//     next();
// }
// app.use(logger)
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:false}))

app.use(express.static(path.join(__dirname,'public')))

app.get('/',function(req,res){
    res.send('Hello world...')
})

app.listen(3000,function(){
    console.log('Server started...')
})